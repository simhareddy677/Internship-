# Data analysis_task-2

### Import required libraries


```python
import pandas as pd
```


```python
df = pd.read_excel("G:\data.xlsx")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>ID</th>
      <th>Salary</th>
      <th>DOJ</th>
      <th>DOL</th>
      <th>Designation</th>
      <th>JobCity</th>
      <th>Gender</th>
      <th>DOB</th>
      <th>10percentage</th>
      <th>...</th>
      <th>ComputerScience</th>
      <th>MechanicalEngg</th>
      <th>ElectricalEngg</th>
      <th>TelecomEngg</th>
      <th>CivilEngg</th>
      <th>conscientiousness</th>
      <th>agreeableness</th>
      <th>extraversion</th>
      <th>nueroticism</th>
      <th>openess_to_experience</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>train</td>
      <td>203097</td>
      <td>420000</td>
      <td>2012-06-01</td>
      <td>present</td>
      <td>senior quality engineer</td>
      <td>Bangalore</td>
      <td>f</td>
      <td>1990-02-19</td>
      <td>84.30</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0.9737</td>
      <td>0.8128</td>
      <td>0.5269</td>
      <td>1.35490</td>
      <td>-0.4455</td>
    </tr>
    <tr>
      <th>1</th>
      <td>train</td>
      <td>579905</td>
      <td>500000</td>
      <td>2013-09-01</td>
      <td>present</td>
      <td>assistant manager</td>
      <td>Indore</td>
      <td>m</td>
      <td>1989-10-04</td>
      <td>85.40</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-0.7335</td>
      <td>0.3789</td>
      <td>1.2396</td>
      <td>-0.10760</td>
      <td>0.8637</td>
    </tr>
    <tr>
      <th>2</th>
      <td>train</td>
      <td>810601</td>
      <td>325000</td>
      <td>2014-06-01</td>
      <td>present</td>
      <td>systems engineer</td>
      <td>Chennai</td>
      <td>f</td>
      <td>1992-08-03</td>
      <td>85.00</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0.2718</td>
      <td>1.7109</td>
      <td>0.1637</td>
      <td>-0.86820</td>
      <td>0.6721</td>
    </tr>
    <tr>
      <th>3</th>
      <td>train</td>
      <td>267447</td>
      <td>1100000</td>
      <td>2011-07-01</td>
      <td>present</td>
      <td>senior software engineer</td>
      <td>Gurgaon</td>
      <td>m</td>
      <td>1989-12-05</td>
      <td>85.60</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0.0464</td>
      <td>0.3448</td>
      <td>-0.3440</td>
      <td>-0.40780</td>
      <td>-0.9194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>train</td>
      <td>343523</td>
      <td>200000</td>
      <td>2014-03-01</td>
      <td>2015-03-01 00:00:00</td>
      <td>get</td>
      <td>Manesar</td>
      <td>m</td>
      <td>1991-02-27</td>
      <td>78.00</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-0.8810</td>
      <td>-0.2793</td>
      <td>-1.0697</td>
      <td>0.09163</td>
      <td>-0.1295</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3993</th>
      <td>train</td>
      <td>47916</td>
      <td>280000</td>
      <td>2011-10-01</td>
      <td>2012-10-01 00:00:00</td>
      <td>software engineer</td>
      <td>New Delhi</td>
      <td>m</td>
      <td>1987-04-15</td>
      <td>52.09</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-0.1082</td>
      <td>0.3448</td>
      <td>0.2366</td>
      <td>0.64980</td>
      <td>-0.9194</td>
    </tr>
    <tr>
      <th>3994</th>
      <td>train</td>
      <td>752781</td>
      <td>100000</td>
      <td>2013-07-01</td>
      <td>2013-07-01 00:00:00</td>
      <td>technical writer</td>
      <td>Hyderabad</td>
      <td>f</td>
      <td>1992-08-27</td>
      <td>90.00</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-0.3027</td>
      <td>0.8784</td>
      <td>0.9322</td>
      <td>0.77980</td>
      <td>-0.0943</td>
    </tr>
    <tr>
      <th>3995</th>
      <td>train</td>
      <td>355888</td>
      <td>320000</td>
      <td>2013-07-01</td>
      <td>present</td>
      <td>associate software engineer</td>
      <td>Bangalore</td>
      <td>m</td>
      <td>1991-07-03</td>
      <td>81.86</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1.5765</td>
      <td>-1.5273</td>
      <td>-1.5051</td>
      <td>-1.31840</td>
      <td>-0.7615</td>
    </tr>
    <tr>
      <th>3996</th>
      <td>train</td>
      <td>947111</td>
      <td>200000</td>
      <td>2014-07-01</td>
      <td>2015-01-01 00:00:00</td>
      <td>software developer</td>
      <td>Asifabadbanglore</td>
      <td>f</td>
      <td>1992-03-20</td>
      <td>78.72</td>
      <td>...</td>
      <td>438</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-0.1590</td>
      <td>0.0459</td>
      <td>-0.4511</td>
      <td>-0.36120</td>
      <td>-0.0943</td>
    </tr>
    <tr>
      <th>3997</th>
      <td>train</td>
      <td>324966</td>
      <td>400000</td>
      <td>2013-02-01</td>
      <td>present</td>
      <td>senior systems engineer</td>
      <td>Chennai</td>
      <td>f</td>
      <td>1991-02-26</td>
      <td>70.60</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1.1128</td>
      <td>-0.2793</td>
      <td>-0.6343</td>
      <td>1.32553</td>
      <td>-0.6035</td>
    </tr>
  </tbody>
</table>
<p>3998 rows × 39 columns</p>
</div>



### Shape and description of the data


```python
df.shape
```




    (3998, 39)




```python
df.size
```




    155922




```python
df.describe
```




    <bound method NDFrame.describe of      Unnamed: 0      ID   Salary        DOJ                  DOL  \
    0         train  203097   420000 2012-06-01              present   
    1         train  579905   500000 2013-09-01              present   
    2         train  810601   325000 2014-06-01              present   
    3         train  267447  1100000 2011-07-01              present   
    4         train  343523   200000 2014-03-01  2015-03-01 00:00:00   
    ...         ...     ...      ...        ...                  ...   
    3993      train   47916   280000 2011-10-01  2012-10-01 00:00:00   
    3994      train  752781   100000 2013-07-01  2013-07-01 00:00:00   
    3995      train  355888   320000 2013-07-01              present   
    3996      train  947111   200000 2014-07-01  2015-01-01 00:00:00   
    3997      train  324966   400000 2013-02-01              present   
    
                          Designation           JobCity Gender        DOB  \
    0         senior quality engineer         Bangalore      f 1990-02-19   
    1               assistant manager            Indore      m 1989-10-04   
    2                systems engineer           Chennai      f 1992-08-03   
    3        senior software engineer           Gurgaon      m 1989-12-05   
    4                             get           Manesar      m 1991-02-27   
    ...                           ...               ...    ...        ...   
    3993            software engineer        New Delhi       m 1987-04-15   
    3994             technical writer         Hyderabad      f 1992-08-27   
    3995  associate software engineer         Bangalore      m 1991-07-03   
    3996           software developer  Asifabadbanglore      f 1992-03-20   
    3997      senior systems engineer           Chennai      f 1991-02-26   
    
          10percentage  ... ComputerScience  MechanicalEngg  ElectricalEngg  \
    0            84.30  ...              -1              -1              -1   
    1            85.40  ...              -1              -1              -1   
    2            85.00  ...              -1              -1              -1   
    3            85.60  ...              -1              -1              -1   
    4            78.00  ...              -1              -1              -1   
    ...            ...  ...             ...             ...             ...   
    3993         52.09  ...              -1              -1              -1   
    3994         90.00  ...              -1              -1              -1   
    3995         81.86  ...              -1              -1              -1   
    3996         78.72  ...             438              -1              -1   
    3997         70.60  ...              -1              -1              -1   
    
         TelecomEngg  CivilEngg  conscientiousness agreeableness extraversion  \
    0             -1         -1             0.9737        0.8128       0.5269   
    1             -1         -1            -0.7335        0.3789       1.2396   
    2             -1         -1             0.2718        1.7109       0.1637   
    3             -1         -1             0.0464        0.3448      -0.3440   
    4             -1         -1            -0.8810       -0.2793      -1.0697   
    ...          ...        ...                ...           ...          ...   
    3993          -1         -1            -0.1082        0.3448       0.2366   
    3994          -1         -1            -0.3027        0.8784       0.9322   
    3995          -1         -1            -1.5765       -1.5273      -1.5051   
    3996          -1         -1            -0.1590        0.0459      -0.4511   
    3997          -1         -1            -1.1128       -0.2793      -0.6343   
    
          nueroticism  openess_to_experience  
    0         1.35490                -0.4455  
    1        -0.10760                 0.8637  
    2        -0.86820                 0.6721  
    3        -0.40780                -0.9194  
    4         0.09163                -0.1295  
    ...           ...                    ...  
    3993      0.64980                -0.9194  
    3994      0.77980                -0.0943  
    3995     -1.31840                -0.7615  
    3996     -0.36120                -0.0943  
    3997      1.32553                -0.6035  
    
    [3998 rows x 39 columns]>




```python
df.info
```




    <bound method DataFrame.info of      Unnamed: 0      ID   Salary        DOJ                  DOL  \
    0         train  203097   420000 2012-06-01              present   
    1         train  579905   500000 2013-09-01              present   
    2         train  810601   325000 2014-06-01              present   
    3         train  267447  1100000 2011-07-01              present   
    4         train  343523   200000 2014-03-01  2015-03-01 00:00:00   
    ...         ...     ...      ...        ...                  ...   
    3993      train   47916   280000 2011-10-01  2012-10-01 00:00:00   
    3994      train  752781   100000 2013-07-01  2013-07-01 00:00:00   
    3995      train  355888   320000 2013-07-01              present   
    3996      train  947111   200000 2014-07-01  2015-01-01 00:00:00   
    3997      train  324966   400000 2013-02-01              present   
    
                          Designation           JobCity Gender        DOB  \
    0         senior quality engineer         Bangalore      f 1990-02-19   
    1               assistant manager            Indore      m 1989-10-04   
    2                systems engineer           Chennai      f 1992-08-03   
    3        senior software engineer           Gurgaon      m 1989-12-05   
    4                             get           Manesar      m 1991-02-27   
    ...                           ...               ...    ...        ...   
    3993            software engineer        New Delhi       m 1987-04-15   
    3994             technical writer         Hyderabad      f 1992-08-27   
    3995  associate software engineer         Bangalore      m 1991-07-03   
    3996           software developer  Asifabadbanglore      f 1992-03-20   
    3997      senior systems engineer           Chennai      f 1991-02-26   
    
          10percentage  ... ComputerScience  MechanicalEngg  ElectricalEngg  \
    0            84.30  ...              -1              -1              -1   
    1            85.40  ...              -1              -1              -1   
    2            85.00  ...              -1              -1              -1   
    3            85.60  ...              -1              -1              -1   
    4            78.00  ...              -1              -1              -1   
    ...            ...  ...             ...             ...             ...   
    3993         52.09  ...              -1              -1              -1   
    3994         90.00  ...              -1              -1              -1   
    3995         81.86  ...              -1              -1              -1   
    3996         78.72  ...             438              -1              -1   
    3997         70.60  ...              -1              -1              -1   
    
         TelecomEngg  CivilEngg  conscientiousness agreeableness extraversion  \
    0             -1         -1             0.9737        0.8128       0.5269   
    1             -1         -1            -0.7335        0.3789       1.2396   
    2             -1         -1             0.2718        1.7109       0.1637   
    3             -1         -1             0.0464        0.3448      -0.3440   
    4             -1         -1            -0.8810       -0.2793      -1.0697   
    ...          ...        ...                ...           ...          ...   
    3993          -1         -1            -0.1082        0.3448       0.2366   
    3994          -1         -1            -0.3027        0.8784       0.9322   
    3995          -1         -1            -1.5765       -1.5273      -1.5051   
    3996          -1         -1            -0.1590        0.0459      -0.4511   
    3997          -1         -1            -1.1128       -0.2793      -0.6343   
    
          nueroticism  openess_to_experience  
    0         1.35490                -0.4455  
    1        -0.10760                 0.8637  
    2        -0.86820                 0.6721  
    3        -0.40780                -0.9194  
    4         0.09163                -0.1295  
    ...           ...                    ...  
    3993      0.64980                -0.9194  
    3994      0.77980                -0.0943  
    3995     -1.31840                -0.7615  
    3996     -0.36120                -0.0943  
    3997      1.32553                -0.6035  
    
    [3998 rows x 39 columns]>



### Univariate analysis 

Univariate analysis is nothing but doing exploratory analysis on each column. we use distplot, histogram to represent each column in the data. 


```python
import matplotlib.pyplot as plt 
import seaborn as sns
```

### Histogram using distplot


```python
sns.distplot(df['Salary'], kde=False) # we can do for any column 
```

    C:\ANAKONDA\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    




    <AxesSubplot:xlabel='Salary'>




    
![png](output_14_2.png)
    



```python
sns.distplot(df['Salary']) #distplot
```




    <AxesSubplot:xlabel='Salary', ylabel='Density'>




    
![png](output_15_1.png)
    


### Understanding the outliers for each column

To see weather a column has outliers or not. Find the mean and median of the column. Generally, Mean and median will be same if the outliers are not present. If the outliers are present mean and median will be different. Mean will get effected if outliers are present.


```python
df.mean()
```

    <ipython-input-17-c61f0c8f89b5>:1: FutureWarning: DataFrame.mean and DataFrame.median with numeric_only=None will include datetime64 and datetime64tz columns in a future version.
      df.mean()
    




    ID                       663794.540520
    Salary                   307699.849925
    10percentage                 77.925443
    12graduation               2008.087544
    12percentage                 74.466366
    CollegeID                  5156.851426
    CollegeTier                   1.925713
    collegeGPA                   71.486171
    CollegeCityID              5156.851426
    CollegeCityTier               0.300400
    GraduationYear             2012.105803
    English                     501.649075
    Logical                     501.598799
    Quant                       513.378189
    Domain                        0.510490
    ComputerProgramming         353.102801
    ElectronicsAndSemicon        95.328414
    ComputerScience              90.742371
    MechanicalEngg               22.974737
    ElectricalEngg               16.478739
    TelecomEngg                  31.851176
    CivilEngg                     2.683842
    conscientiousness            -0.037831
    agreeableness                 0.146496
    extraversion                  0.002763
    nueroticism                  -0.169033
    openess_to_experience        -0.138110
    dtype: float64




```python
df.median()
```

    <ipython-input-18-6d467abf240d>:1: FutureWarning: DataFrame.mean and DataFrame.median with numeric_only=None will include datetime64 and datetime64tz columns in a future version.
      df.median()
    




    ID                       639600.000000
    Salary                   300000.000000
    10percentage                 79.150000
    12graduation               2008.000000
    12percentage                 74.400000
    CollegeID                  3879.000000
    CollegeTier                   2.000000
    collegeGPA                   71.720000
    CollegeCityID              3879.000000
    CollegeCityTier               0.000000
    GraduationYear             2013.000000
    English                     500.000000
    Logical                     505.000000
    Quant                       515.000000
    Domain                        0.622643
    ComputerProgramming         415.000000
    ElectronicsAndSemicon        -1.000000
    ComputerScience              -1.000000
    MechanicalEngg               -1.000000
    ElectricalEngg               -1.000000
    TelecomEngg                  -1.000000
    CivilEngg                    -1.000000
    conscientiousness             0.046400
    agreeableness                 0.212400
    extraversion                  0.091400
    nueroticism                  -0.234400
    openess_to_experience        -0.094300
    dtype: float64



We can see that outliers are present in salary, 10percentage, collegeTier, english, quant, domain, domain, computer programming, electonics and semicon, computer science, mechanical engg, telecom engg, civil engg columns.

### Frequency distribution of each column with respect to jobcity


```python
df.JobCity.value_counts()
```




    Bangalore                  627
    -1                         461
    Noida                      368
    Hyderabad                  335
    Pune                       290
                              ... 
    Jowai                        1
    PATNA                        1
    Navi Mumbai , Hyderabad      1
    Maharajganj                  1
    Bhubaneswar                  1
    Name: JobCity, Length: 339, dtype: int64



### Bivariate analysis 

Bivariate analysis is nothing but doing exploratory analysis on whole data (2 or more columns). we use boxplot, scatterplot, stripplot, swarmplot to represent two or more column in the data.


```python
df.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>ID</th>
      <th>Salary</th>
      <th>DOJ</th>
      <th>DOL</th>
      <th>Designation</th>
      <th>JobCity</th>
      <th>Gender</th>
      <th>DOB</th>
      <th>10percentage</th>
      <th>...</th>
      <th>ComputerScience</th>
      <th>MechanicalEngg</th>
      <th>ElectricalEngg</th>
      <th>TelecomEngg</th>
      <th>CivilEngg</th>
      <th>conscientiousness</th>
      <th>agreeableness</th>
      <th>extraversion</th>
      <th>nueroticism</th>
      <th>openess_to_experience</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>train</td>
      <td>203097</td>
      <td>420000</td>
      <td>2012-06-01</td>
      <td>present</td>
      <td>senior quality engineer</td>
      <td>Bangalore</td>
      <td>f</td>
      <td>1990-02-19</td>
      <td>84.3</td>
      <td>...</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0.9737</td>
      <td>0.8128</td>
      <td>0.5269</td>
      <td>1.3549</td>
      <td>-0.4455</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 39 columns</p>
</div>



We have plotted a numerical column with categorical column


```python
sns.scatterplot(x='Designation', y='Salary', data=df)
```




    <AxesSubplot:xlabel='Designation', ylabel='Salary'>




    
![png](output_27_1.png)
    



```python
sns.scatterplot(x='12graduation', y='12percentage', data=df)
```




    <AxesSubplot:xlabel='12graduation', ylabel='12percentage'>




    
![png](output_28_1.png)
    



```python
sns.barplot(x='12graduation', y='12percentage', data=df)
```




    <AxesSubplot:xlabel='12graduation', ylabel='12percentage'>




    
![png](output_29_1.png)
    



```python
sns.boxplot(x='12graduation', y='12percentage', data=df)
```




    <AxesSubplot:xlabel='12graduation', ylabel='12percentage'>




    
![png](output_30_1.png)
    



```python
sns.stripplot(x='12graduation', y='12percentage', data=df)
```




    <AxesSubplot:xlabel='12graduation', ylabel='12percentage'>




    
![png](output_31_1.png)
    



```python
sns.violinplot(x='12graduation', y='12percentage', data=df)
```




    <AxesSubplot:xlabel='12graduation', ylabel='12percentage'>




    
![png](output_32_1.png)
    


We looked in to Bivariant plots like violinplot, barplot, scatterplot, stripplot, boxplot. We just looked at 12th percentage for each 12th graduation year. We have taken X-axis as graduation year and Y-axis as percentage. 

### Research question

Finding the relation between gender and specialization


```python
df2 = df[['Gender', 'Specialization']]
```


```python
df2
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Gender</th>
      <th>Specialization</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>1</th>
      <td>m</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>2</th>
      <td>f</td>
      <td>information technology</td>
    </tr>
    <tr>
      <th>3</th>
      <td>m</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>4</th>
      <td>m</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3993</th>
      <td>m</td>
      <td>information technology</td>
    </tr>
    <tr>
      <th>3994</th>
      <td>f</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>3995</th>
      <td>m</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>3996</th>
      <td>f</td>
      <td>computer science &amp; engineering</td>
    </tr>
    <tr>
      <th>3997</th>
      <td>f</td>
      <td>information technology</td>
    </tr>
  </tbody>
</table>
<p>3998 rows × 2 columns</p>
</div>




```python
# Doing gender Label encoding
from sklearn import preprocessing 
label_encoder = preprocessing.LabelEncoder()
df['Gender'] = label_encoder.fit_transform(df['Gender'])
df['Gender'].value_counts()
```




    1    3041
    0     957
    Name: Gender, dtype: int64




```python
df4 = df[['Gender', 'Specialization']]
```


```python
df4
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Gender</th>
      <th>Specialization</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>information technology</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3993</th>
      <td>1</td>
      <td>information technology</td>
    </tr>
    <tr>
      <th>3994</th>
      <td>0</td>
      <td>electronics and communication engineering</td>
    </tr>
    <tr>
      <th>3995</th>
      <td>1</td>
      <td>computer engineering</td>
    </tr>
    <tr>
      <th>3996</th>
      <td>0</td>
      <td>computer science &amp; engineering</td>
    </tr>
    <tr>
      <th>3997</th>
      <td>0</td>
      <td>information technology</td>
    </tr>
  </tbody>
</table>
<p>3998 rows × 2 columns</p>
</div>




```python
import seaborn as sns
sns.set(rc={'figure.figsize':(11.7,8.27)})
sns.scatterplot(x='Gender', y='Specialization', data=df4)
```




    <AxesSubplot:xlabel='Gender', ylabel='Specialization'>




    
![png](output_41_1.png)
    


We have plotted Gender on X-axis and Specializations on Y-axis. We clearly see that there is a relationship between girls doesn't take electronics and computer engineering, mechanical and automation, control and instrumentation, metallurgical, other, embedded systems, electrical and power, automobile/automotive, polymer, mechanical&production, power system, instrumentation, industrical & management, computer and communication, information science, internal combustion engine, computer networking, electronics. So, we can conclude that girls more likely to choose only some specializations. Boys have choosen almost all the specializations. 


```python

```
